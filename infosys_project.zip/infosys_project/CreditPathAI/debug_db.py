import sqlite3
import os

def check_db(path):
    if not os.path.exists(path):
        print(f"--- MISSING: {path} ---")
        return
    print(f"--- FOUND: {path} (Size: {os.path.getsize(path)} bytes) ---")
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    try:
        cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [t[0] for t in cur.fetchall()]
        print(f"Tables: {tables}")
        for table in tables:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            count = cur.fetchone()[0]
            print(f"  {table}: {count} rows")
            
            # If it's the borrowers table, show first entry
            if table == 'borrowers':
                cur.execute("SELECT * FROM borrowers LIMIT 1")
                print(f"    Sample Borrower: {cur.fetchone()}")
    except Exception as e:
        print(f"Error checking {path}: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    check_db("creditpath.db")
    check_db("backend/app/creditpath.db")
    
    # Check what path SQL Alchemy would use
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    BACKEND_DIR = os.path.dirname(CURRENT_DIR)
    PROJECT_ROOT = os.path.dirname(BACKEND_DIR)
    EXPECTED_DB = os.path.join(PROJECT_ROOT, 'creditpath.db')
    print(f"\nExpected DB path from logic: {EXPECTED_DB}")
    check_db(EXPECTED_DB)
