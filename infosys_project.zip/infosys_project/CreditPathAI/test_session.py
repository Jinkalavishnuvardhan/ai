import sys
import os

# Add the app directory to sys.path
sys.path.append(os.path.join(os.getcwd(), 'backend', 'app'))

try:
    from database import SessionLocal, SQLALCHEMY_DATABASE_URL
    from models import Borrower, Loan
    from sqlalchemy.orm import joinedload
    
    print(f"Testing connection to: {SQLALCHEMY_DATABASE_URL}")
    db = SessionLocal()
    
    print("Attempting to count borrowers...")
    b_count = db.query(Borrower).count()
    print(f"Borrower count: {b_count}")
    
    print("Attempting to fetch loans with joined borrowers...")
    loans = db.query(Loan).options(joinedload(Loan.borrower)).limit(5).all()
    print(f"Successfully fetched {len(loans)} loans.")
    
    for l in loans:
        print(f"  Loan ID: {l.id}, Borrower: {l.borrower.full_name}")
        
    db.close()
    print("\nSUCCESS: Database connection and models are working correctly.")

except Exception as e:
    print(f"\nFAILURE: {e}")
    import traceback
    traceback.print_exc()
