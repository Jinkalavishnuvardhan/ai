import sys
import os

# Set paths so imports work
sys.path.append(os.path.join(os.getcwd(), 'CreditPathAI', 'backend', 'app'))

from database import SessionLocal
from models import Loan, Borrower
# Import main from the path added above
import main

def test_query():
    db = SessionLocal()
    try:
        print("Testing DB Connection...")
        count = db.query(Borrower).count()
        print(f"Borrower count: {count}")
        
        print("Testing API Function...")
        # main.get_borrowers expects db
        results = main.get_borrowers(skip=0, limit=5, db=db)
        print(f"API Returned {len(results)} results")
        print(results[0])
            
    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    test_query()
